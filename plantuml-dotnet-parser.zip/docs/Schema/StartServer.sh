
npm install http-server
./node_modules/.bin/http-server -o